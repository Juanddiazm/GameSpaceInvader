package hilos;

import java.util.ArrayList;

import interfaz.InterfazJuego;
import mundo.Invasor;

public class HiloInvasor extends Thread {
	
	public final static int TIEMPO_ESPERA = 50;
	public final static int MOV_VERT = 15;
	private ArrayList<Invasor> invasores;
	private InterfazJuego principal;
	
	/**
	 * @param invasor
	 * @param juego
	 */
	public HiloInvasor(ArrayList<Invasor> invasores, InterfazJuego pPrincipal) {
		this.invasores = invasores;
		principal= pPrincipal  ;
	}
	
	public void run(){
		while (!principal.termino()){
		try {
			
			while(invasores.get(0).getPosX()<principal.getWidth()-55){
			for(int i =0; i< invasores.size(); i++){
				invasores.get(i).mover(invasores.get(i).getMovX());
			}
			
			principal.actualizarJuego();
			sleep(TIEMPO_ESPERA);
			
			}
			
			//Movimiento hacia abajo cuando toca borde derecho
			for(int i = 0; i< invasores.size(); i++){
				invasores.get(i).mover(MOV_VERT);
			}
			
			while(invasores.get(34).getPosX()>0){
				
				for(int i =0; i< invasores.size(); i++){
					invasores.get(i).mover(-(invasores.get(i).getMovX()));

			}
				principal.actualizarJuego();
				sleep(TIEMPO_ESPERA);
			}
			
			//Movimiento hacia abajo cuando toca borde izquierdo
			for(int i = 0; i< invasores.size(); i++){
				invasores.get(i).mover(MOV_VERT);
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
}
