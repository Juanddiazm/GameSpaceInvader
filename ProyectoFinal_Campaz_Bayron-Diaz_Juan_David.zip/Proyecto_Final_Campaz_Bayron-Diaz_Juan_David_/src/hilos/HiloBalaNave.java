package hilos;

import interfaz.InterfazJuego;
import mundo.Disparo;

public class HiloBalaNave extends Thread {

	private Disparo bala;
	private InterfazJuego principal;

	public HiloBalaNave(Disparo bala, InterfazJuego principal) {
		this.bala = bala;
		this.principal = principal;
	}

	public void run() {
		if(!principal.termino()){
		bala.setPosX(principal.darNave().getPosX()+22);
		bala.setPosY(principal.darNave().getPosY());
		
		while(bala.getPosY()>-5){
			
			try {	
				sleep(10);
				bala.mover(-20);

				
				principal.actualizarJuego();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		principal.getJuego().setPuedeDispararDeNuevo(true);
	}
	}

}
