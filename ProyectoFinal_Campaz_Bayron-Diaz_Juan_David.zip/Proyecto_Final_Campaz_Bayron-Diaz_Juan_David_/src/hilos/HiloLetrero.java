package hilos;

import interfaz.InterfazJuego;

public class HiloLetrero extends Thread {
	private InterfazJuego principal;

	/**
	 * @param principal
	 */
	public HiloLetrero(InterfazJuego principal) {
		this.principal = principal;
	}

	public void run() {
		try {
			while (!principal.termino()) {
				if(principal.getJuego().isImpacto()){
			 sleep(500);
				principal.getJuego().setImpacto(false);
				}
			}
		} catch (InterruptedException e) {
		}
	}
 }
