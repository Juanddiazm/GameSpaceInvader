package hilos;

import interfaz.InterfazJuego;
import mundo.Nave;

public class HiloNave extends Thread {

	public static final int VEL_NAVE = 5;
	
	private Nave nave;
	private InterfazJuego principal;

	public HiloNave(Nave nave, InterfazJuego principal) {
		this.nave = nave;
		this.principal = principal;
	}

	public void run() {
		while (!principal.termino()) {
			principal.actualizarJuego();
			try {
				sleep(VEL_NAVE);
			} catch (InterruptedException e) {
			}
		}
	}
}