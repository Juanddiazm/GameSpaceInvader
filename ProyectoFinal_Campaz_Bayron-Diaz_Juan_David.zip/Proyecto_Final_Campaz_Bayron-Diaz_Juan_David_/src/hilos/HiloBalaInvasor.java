package hilos;

import interfaz.InterfazJuego;
import mundo.Disparo;

public class HiloBalaInvasor extends Thread {

	public static final int TIEMPO_ESP = 30;
	
	private Disparo bala;
	private InterfazJuego principal;
	
	public HiloBalaInvasor(Disparo bala, InterfazJuego principal) {
		this.bala = bala;
		this.principal = principal;
	}

	public void run() {

		int contador = 0;

		while (!principal.termino()) {
			
			try {
				sleep(TIEMPO_ESP);
				contador = contador + bala.getMovY();

				bala.mover(bala.getMovY());
				principal.actualizarJuego();
				if (contador > principal.getHeight()) {

					int tiempoEspera = (int) (Math.random() * 200) + 100;
					int invasorAleatorio = (int) (Math.random() * principal.darInvasores().size());
					sleep(tiempoEspera);
					if (principal.darInvasores().get(invasorAleatorio).isEstaVivo()) {
						bala.setPosY(principal.darInvasores().get(invasorAleatorio).getPosY());
						bala.setPosX(principal.darInvasores().get(invasorAleatorio).getPosX());
						contador = 0;
					}
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
