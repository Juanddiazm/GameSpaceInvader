package interfaz;

import java.awt.Dimension;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import hilos.HiloBalaInvasor;
import hilos.HiloBalaNave;
import hilos.HiloInvasor;
import hilos.HiloLetrero;
import hilos.HiloNave;
import mundo.CampoVacioException;
import mundo.Fondo;
import mundo.Invasor;
import mundo.Juego;
import mundo.Nave;
import mundo.NombreYaExisteException;
import mundo.Puntaje;

public class InterfazJuego extends JFrame {

	private HiloNave hiloNave;
	public final static int CUADROS_POR_SEGUNDOS = 120;

	private PanelInicio panelInicio;
	private PanelEscenario panelEscenario;
	private HiloLetrero hiloLetrero;
	private Juego juego;
	private boolean enInicio;
	// Atributos para mostrar los puntos ganados al dar el impacto
	private int marcadorX, marcadorY;
	
	private PanelSeleccionFondo panelSeleccionFondo;
	
	public InterfazJuego() {

		setTitle("Spaces Invader");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		panelInicio = new PanelInicio(this);
		add(panelInicio);
		enInicio= true;
		setSize(1010, 700);
		setResizable(false);
		// Ventana inicie en el centro.
		this.setLocationRelativeTo(null);
	}
	

	public void nuevaPartida() {
		
		panelEscenario = new PanelEscenario(this);
		addKeyListener(panelEscenario);
		juego = new Juego();
		enInicio = false;
		panelEscenario.cambiarInvasores(juego.darPrimerInvasor());
		panelEscenario.cambiarBalaInvasor(juego.getBalaInvasor());
		panelEscenario.cambiarBalaNave(juego.getBalaNave());
		hiloNave = new HiloNave(juego.getNave(), this);
		hiloNave.start();
		hiloLetrero = new HiloLetrero(this);
		hiloLetrero.start();
		// Mejora el parpadejo del repaint
		panelEscenario.setDoubleBuffered(true);
		if(panelSeleccionFondo != null){
		panelEscenario.setFondo(juego.buscarFondo(panelSeleccionFondo.getSeleccion()));
		setExtendedState(ICONIFIED);
		setExtendedState(JFrame.NORMAL);

		}else{
			Fondo nuevo = new Fondo(10,"data/images/fondoInicial.jpg"); 
			panelEscenario.setFondo(nuevo);
			setExtendedState(ICONIFIED);
			setExtendedState(JFrame.NORMAL);
		}
		
		remove(panelInicio);
		add(panelEscenario);
		panelEscenario.updateUI();
		iniciarHiloInvasores();
		iniciarHiloBalaInvasores();
	
	}
	
	public void cambiarFondo(){
		juego.cambiarFondo(panelSeleccionFondo.getSeleccion());
		remove(panelSeleccionFondo);
		add(panelInicio);
	}
	
	
	public void mostrarHighScores(){
		juego = new Juego();
		juego.setJuegoActivo(false);
		String mensaje = " ";
		juego.ordenarPuntajesAscendentemente();
		for(int i = juego.darPuntajes().size()-1; i >= 0 ; i--){
			mensaje += juego.darPuntajes().get(i).getNombreJugador() + "                   " + juego.darPuntajes().get(i).getPuntaje() + "\n";
		}
		
		JOptionPane.showMessageDialog(null, mensaje, "Los mas altos scores", JOptionPane.INFORMATION_MESSAGE);
		
	}

	public void actualizarJuego()  {
		verficarEstado();
		if (!juego.isJuegoActivo() && !enInicio) {
			enInicio = true;
			int respuesta = JOptionPane.showConfirmDialog(null,
					"Fin del juego" + "\n" + "Deseas registrar tu score");
			if (respuesta == JOptionPane.YES_OPTION) {
			String nombre = JOptionPane.showInputDialog(null, "Digita tu nombre", "Ingreso Score", JOptionPane.INFORMATION_MESSAGE);
				agregarPuntaje(nombre);
				try {
					juego.guardarPuntaje();
					remove(panelEscenario);
					add(panelInicio);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else if(respuesta==JOptionPane.NO_OPTION){
				remove(panelEscenario);
				enInicio =true;
				add(panelInicio);
			}

		}
		panelEscenario.repaint();
		panelEscenario.cambiarNave(juego.getNave());
	}
	
	public void agregarPuntaje(String nombre){
		try {
			juego.agregarPuntaje(nombre);
		} catch (NombreYaExisteException | CampoVacioException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}


	
	public void verficarEstado(){
		juego.verificarEstado();
	}
	public void iniciarHiloInvasores() {

		HiloInvasor nuevo = new HiloInvasor(juego.darInvasores(), this);
		nuevo.start();
	}

	public void iniciarHiloBalaInvasores() {
		HiloBalaInvasor nuevo = new HiloBalaInvasor(juego.getBalaInvasor(), this);
		nuevo.start();
	}

	public void iniciarHiloBalaNave() {

		HiloBalaNave nueva = new HiloBalaNave(juego.getBalaNave(), this);
		nueva.start();

	}
	
	public void salir(){
		int opcion;
		boolean guardo=false;
		opcion = JOptionPane.showConfirmDialog(this, "�Desea guardar el juego actual antes de salir?");
			if(opcion==JOptionPane.YES_OPTION){
				guardo = guardar();
				remove(panelEscenario);
				enInicio= true;
				add(panelInicio);
			}
			else if(opcion==JOptionPane.NO_OPTION){
			remove(panelEscenario);
			enInicio= true;
			add(panelInicio);
		}		
	}
	
	public boolean guardar(){
		boolean guardo = false;
		
		try {
			juego.guardarJuego();
			guardo =true;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return guardo;
		
	}
	
	public void continuarJuego(){
		try {
			if(juego != null && panelEscenario != null){
			juego.continuarJuego();
			panelEscenario.cambiarInvasores(juego.darPrimerInvasor());
			panelEscenario.cambiarBalaInvasor(juego.getBalaInvasor());
			panelEscenario.cambiarBalaNave(juego.getBalaNave());
			iniciarHiloInvasores();
			iniciarHiloBalaInvasores();
			juego.setJuegoActivo(true);
			remove(panelInicio);
			add(panelEscenario);
			enInicio=false;
			}else{
				juego = new Juego();
				juego.continuarJuego();
				panelEscenario = new PanelEscenario(this);
				panelEscenario.cambiarInvasores(juego.darPrimerInvasor());
				panelEscenario.cambiarBalaInvasor(juego.getBalaInvasor());
				panelEscenario.cambiarBalaNave(juego.getBalaNave());
				iniciarHiloInvasores();
				iniciarHiloBalaInvasores();
				juego.setJuegoActivo(true);
				remove(panelInicio);
				add(panelEscenario);
				addKeyListener(panelEscenario);
 		
				panelEscenario.updateUI();
				enInicio=false;
				
				setExtendedState(ICONIFIED);
				setExtendedState(JFrame.NORMAL);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void opciones(){
		juego = new Juego();
		juego.setJuegoActivo(false);
		panelSeleccionFondo = new PanelSeleccionFondo(this);
		remove(panelInicio);
		add(panelSeleccionFondo);
		panelSeleccionFondo.updateUI();
	}
	
	
	public void dispose(){
		if(!enInicio){
		salir();
		}else{
			System.exit(0);
		}
	}
	

	public Juego getJuego() {
		return juego;
	}

	public void setJuego(Juego juego) {
		this.juego = juego;
	}

	public static void main(String[] args) {
		InterfazJuego ventana = new InterfazJuego();
		ventana.setVisible(true);

	}

	public ArrayList<Invasor> darInvasores() {
		return juego.darInvasores();
	}

	public Nave darNave() {
		return juego.getNave();
	}


	public PanelEscenario getPanelEscenario() {
		return panelEscenario;
	}


	public void setPanelEscenario(PanelEscenario panelEscenario) {
		this.panelEscenario = panelEscenario;
	}

	public HiloLetrero getHiloLetrero() {
		return hiloLetrero;
	}


	public void setHiloLetrero(HiloLetrero hiloLetrero) {
		this.hiloLetrero = hiloLetrero;
	}

	
	public boolean termino(){
		return !juego.isJuegoActivo();
	}
	
	public int darPuntajeActual(){
		return juego.getPuntajeActual();
	}

	public int getMarcadorX() {
		return juego.getMarcadorX();
	}

	public int getMarcadorY() {
		return  juego.getMarcadorY();
	}
	
	public ArrayList<Fondo> darFondos(){
		return juego.darFondos();
	}
	
	public String darFondoActual(){
		return juego.darFondoActual();
	}


}
