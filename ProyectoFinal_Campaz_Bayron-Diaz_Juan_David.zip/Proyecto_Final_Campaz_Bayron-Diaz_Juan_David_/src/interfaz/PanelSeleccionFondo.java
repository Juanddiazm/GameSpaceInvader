package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelSeleccionFondo extends JPanel implements ActionListener{
	public static final String[] CONSTANTES= {"0","1","2", "3","4","5", "6", "7", "8", "9"};
	public static final String INICIAR="iniciar";
	private String seleccion;
	private InterfazJuego principal;

	private JLabel lbSelecFondo;
	
	private JButton butFondo;
	private JButton iniciar;
	public PanelSeleccionFondo(InterfazJuego pPrincipal) {
		principal = pPrincipal;
		setLayout(new BorderLayout());
		JPanel panelBotones= new JPanel();
		panelBotones.setLayout(new GridLayout(2, 5));
		seleccion= "";
		lbSelecFondo= new JLabel("Seleccione el escenario");
		setSize(1040, 700);
		iniciar= new JButton("Seleccionar Escenario");
		iniciar.setActionCommand(INICIAR);
		iniciar.addActionListener(this);
		add(iniciar, BorderLayout.SOUTH);
		
		for (int i = 0; i < principal.darFondos().size(); i++) {
			butFondo=new JButton(new ImageIcon(principal.darFondos().get(i).getRuta()+""));
			butFondo.setActionCommand(CONSTANTES[i]);
			butFondo.addActionListener(this);
			panelBotones.add(butFondo);
		}
		add(lbSelecFondo, BorderLayout.NORTH);
		add(panelBotones, BorderLayout.CENTER);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(INICIAR)){
			principal.cambiarFondo();
		}else
		seleccion=e.getActionCommand();
		
	}
	
	public int getSeleccion(){
		return Integer.parseInt(seleccion);
	}
	
}
