package interfaz;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class PanelInicio extends JPanel implements MouseListener{

	private InterfazJuego principal;
	
	public PanelInicio(InterfazJuego pPrincipal){
		
		principal = pPrincipal;
		addMouseListener(this);
		
	}
	
	public void paintComponent(Graphics g){
		super.paintComponents(g);
		
		Graphics2D g2 = (Graphics2D) g;
		
		g2.drawImage(new ImageIcon( "data/fondo.jpg").getImage(), 0, 0, this);
		g2.drawImage(new ImageIcon( "data/gifs/text.gif").getImage(), 280, 80, this);
		g2.drawImage(new ImageIcon( "data/gifs/imagen1.gif").getImage(), 80, 190, this);
		g2.drawImage(new ImageIcon( "data/gifs/imagen2.gif").getImage(), 80, 290, this);
		g2.drawImage(new ImageIcon( "data/gifs/imagen3.gif").getImage(), 80, 390, this);
		g2.drawImage(new ImageIcon( "data/gifs/imagen4.gif").getImage(), 80, 490, this);

	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		int clicY = arg0.getY();
		
		if(clicY>150 && clicY<240){
			//Nueva Partida
			principal.nuevaPartida();
			
		}else if(clicY>260 && clicY<350){
			//Continuar
			principal.continuarJuego();
			
		}else if(clicY>370 && clicY<460){
			//HighScores
			principal.mostrarHighScores();
			
		}else if(clicY>480 && clicY<570){
			//opciones
			principal.opciones();
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	
}
