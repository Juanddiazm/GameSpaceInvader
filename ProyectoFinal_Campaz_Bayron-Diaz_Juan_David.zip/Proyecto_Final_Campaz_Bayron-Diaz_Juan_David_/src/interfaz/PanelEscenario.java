package interfaz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import mundo.Disparo;
import mundo.Fondo;
import mundo.Invasor;
import mundo.Juego;
import mundo.Nave;

public class PanelEscenario extends JPanel implements KeyListener {

	private Invasor primerInvasor;
	private InterfazJuego principal;
	private Disparo balaInvasor;
	private Disparo balasNave;
	ImageIcon dibujoNave;
	private Nave nave;
	private ArrayList<Nave> listaVidas;
	private boolean yaDisparo;
	private Fondo fondo;
	
	
	// iconos que indican la vida 
	private Nave vida;

	public PanelEscenario(InterfazJuego pPrincipal) {
		balaInvasor = new Disparo(10, 10, Color.RED, -10, 10, 10);
		principal = pPrincipal;
		dibujoNave = new ImageIcon("data/images/shipSkin.gif");
		addKeyListener(this);
		
		
		
		// inicializa las vidas
		listaVidas = new ArrayList<Nave>();
		for (int i = 0; i < 3; i++) {
			vida = new Nave(48 + (i * 20), 10, Color.WHITE, 0);
			listaVidas.add(vida);
		}
	}

	public Fondo getFondo() {
		return fondo;
	}

	public void setFondo(Fondo fondo) {
		this.fondo = fondo;
	}

	public void cambiarNave(Nave nave) {
		this.nave = nave;

	}

	public void cambiarInvasores(Invasor inv) {
		primerInvasor = inv;
	}

	public void cambiarBalaInvasor(Disparo bala) {
		balaInvasor = bala;
	}

	public void cambiarBalaNave(Disparo bala) {
		balasNave = bala;
	}

	public void paintComponent(Graphics g) {
		
		super.paintComponents(g);

		Graphics2D g2 = (Graphics2D) g;
		if(fondo!=null){
		g2.drawImage(new ImageIcon(fondo.getRuta()).getImage(), 0, 0, this);
		}else{
			g2.drawImage(new ImageIcon("data/images/fondoInicial.jpg").getImage(), 0, 0, this);
		}
		
		// DIBUJA LOS INVASORES
		Invasor actual = primerInvasor;
		while (actual != null) {
			if (actual.isEstaVivo()) {
				if (actual.getTipoDeInvasor() == Invasor.INVASOR1) {
					g2.drawImage(new ImageIcon("data/images/alien1Skin.gif").getImage(), actual.getPosX(),
							actual.getPosY()+25, this);

				} else if (actual.getTipoDeInvasor() == Invasor.INVASOR2) {
					g2.drawImage(new ImageIcon("data/images/alien2Skin.gif").getImage(), actual.getPosX(),
							actual.getPosY()+25, this);

				} else if (actual.getTipoDeInvasor() == Invasor.INVASOR3) {
					g2.drawImage(new ImageIcon("data/images/alien3Skin.gif").getImage(), actual.getPosX(),
							actual.getPosY()+25, this);

				}
			}
			actual = actual.getSiguiente();
		}
		// DIBUJA LA NAVE
		g2.drawImage(dibujoNave.getImage(), principal.getJuego().getNave().getPosX(),
				principal.getJuego().getNave().getPosY(), this);

		// DIBUJA LA BALA DE LOS INVASORES
		Rectangle2D rect = new Rectangle2D.Double(balaInvasor.getPosX(), balaInvasor.getPosY(), balaInvasor.ANCHOBALA,
				balaInvasor.LARGOBALA);
		g2.setColor(balaInvasor.getColor());
		g2.fill(rect);

		// DIBUJA LA BALA DE LA NAVE
		if(yaDisparo){
		Rectangle2D rect2 = new Rectangle2D.Double(balasNave.getPosX(), balasNave.getPosY(), balasNave.ANCHOBALA,
				balasNave.LARGOBALA);
		g2.setColor(balasNave.getColor());
		g2.fill(rect2);
		}
		
		//Dibuja el score actual
		g2.setColor(Color.WHITE);
		g2.drawString("Score: "+ principal.darPuntajeActual(), 300, 20);
		
			// pinta las vidas en la parte superior izquierda
			g2.setColor(Color.WHITE);
			g2.drawString("Lives:", 11, 20);
			for (int l = 0; l < nave.getNumVida(); l++) {
				g2.drawImage(new ImageIcon("data/images/shipSkinSmall.gif").getImage(), listaVidas.get(l).getPosX(),
						listaVidas.get(l).getPosY(), this);
			}
			
			// Indica donde debe pintarse el letrero "100+"
			if (principal.getJuego().isImpacto()) {
				principal.getJuego().setImpacto(true);
				g2.setColor(Color.WHITE);
				
				g.drawString("+ 100", principal.getMarcadorX() + 20,principal.getMarcadorY()-1);

			}
			Polygon star = new Polygon(new int[] { 0, 6, 24, 9, 15, 0, -15, -9, -24, -6 },
					new int[] { -25, -8, -8, 3, 20, 9, 20, 3, -8, -8 }, 10);
			g2.scale(0.5, 0.5);
			g2.setColor(new Color((int) (Math.random() * 0x1000000)));
			int aleatorioX = (int) ((Math.random() * 3120) + 1);
			int aleatorioY = (int) ((Math.random() * 2100) + 1);
			g2.translate(aleatorioX, aleatorioY);
			g2.fillPolygon(star);                        	
			
		}

	@Override
	public void keyPressed(KeyEvent arg0) {
		
		int codigo = arg0.getKeyCode();

		if (codigo == 37) {
			nave.mover(-30);

		} else if (codigo == 39) {
			nave.mover(30);

		} else if (codigo == 32) {
			yaDisparo = true;
			if (principal.getJuego().isPuedeDispararDeNuevo()) {
				principal.iniciarHiloBalaNave();
				principal.getJuego().setPuedeDispararDeNuevo(false);
				
			}

		}

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public ArrayList<Nave> getListaVidas() {
		return listaVidas;
	}
}
