package mundo;

import java.awt.Color;


public class Invasor extends ObjetoDeJuegoEnMovimiento {
	// Constantes de cada uno de los invasores
	public static final int INVASOR1 = 1;
	public static final int INVASOR2 = 2;
	public static final int INVASOR3 = 3;
	public static final int INAVASORJEFE1 = 4;

	
	// Define el tipo de invasor
	private int tipoDeInvasor;
	// define el ancho y el alto del invasor
	private int ancho, alto;
	//
	private boolean estaVivo;
	
	private Invasor siguiente;

	public Invasor getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(Invasor siguiente) {
		this.siguiente = siguiente;
	}

	/**
	 * @param posX
	 *            Posici�n en el eje x del objeto.
	 * @param posY
	 *            Posici�n en el eje y del objeto.
	 * @param color
	 *            Color del objeto.
	 * @param pMovX
	 *            Cambio en la posicion en el eje x del objeto.
	 * @param pMovY
	 *            Cambio en la posicion en el eje y del objeto.
	 */
	public Invasor(int pPosX, int pPosY, Color pColor, int pMovX, int pMovY, int pTipoDeInvasor, int pAncho,int  pAlto) {
		super(pPosX, pPosY, pColor, pMovX, pMovY);
		tipoDeInvasor = pTipoDeInvasor;
		ancho = pAncho;
		alto = pAlto;
		
		estaVivo = true;
		
	}

	public int getTipoDeInvasor() {
		return tipoDeInvasor;
	}

	public void setTipoDeInvasor(int tipoDeInvasor) {
		this.tipoDeInvasor = tipoDeInvasor;
	}

	public boolean isEstaVivo() {
		return estaVivo;
	}

	public void setEstaVivo(boolean estaVivo) {
		this.estaVivo = estaVivo;
	}
	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setAlto(int alto) {
		this.alto = alto;
	}

	/**
	 * Retorna los limites de un invasor dado en forma de rectangulo
	 */
	@Override
	public int[] getLimites() {
		int[] ubicacion = new int[3];
		ubicacion[0] = getPosX();
		ubicacion[1] = getPosY();
		ubicacion[2] = 40;
		return ubicacion;
	}
/**
 * movimiento del(los) invasor(es)
 */

	@Override
	public void mover(int mov) {
		
		//Como los invasores se mueven de manera horizontal y vertical (Si el parametro es super.getMoxX() 
		//el movimiento es en X de lo contario el movimiento es en Y
		
		if(mov== super.getMovX() || mov == -(super.getMovX()))
		setPosX(getPosX()+mov);
		else
		setPosY(getPosY()+mov);
	}

}
