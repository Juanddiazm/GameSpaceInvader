package mundo;

public class NombreYaExisteException extends Exception {

	public NombreYaExisteException(String mensaje){
		super(mensaje);
	}
}
