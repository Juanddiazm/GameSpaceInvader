package mundo;

import java.awt.Color;

public abstract class ObjetoDeJuegoEnMovimiento extends ObjetoJuego implements Movimiento {

	private int movX;
	private int movY;

	/**
	 * 
	 * @param pPosX
	 *            Posici�n en el eje x del objeto.
	 * @param pPosY
	 *            Posici�n en el eje y del objeto.
	 * @param pColor
	 *            Color del objeto.
	 * @param pMovX
	 *            Cambio en la posicion en el eje x del objeto.
	 * @param pMovY
	 *            Cambio en la posicion en el eje y del objeto.
	 */
	public ObjetoDeJuegoEnMovimiento(int pPosX, int pPosY, Color pColor, int pMovX, int pMovY) {
		super(pPosX, pPosY, pColor);
		movX = pMovX;
		movY = pMovY;
	}

	public int getMovX() {
		return movX;
	}

	/**
	 * @param posX
	 * @param posY
	 * @param color
	 */

	/**
	 * 
	 * @param movX
	 */
	public void setMovX(int pMovX) {
		movX = pMovX;
	}

	public int getMovY() {
		return movY;
	}

	/**
	 * 
	 * @param movY
	 */
	public void setMovY(int pMovY) {
		movY = pMovY;
	}


}