package mundo;

import java.awt.Color;


public class Disparo extends ObjetoDeJuegoEnMovimiento implements Intersectar{
	
	public final static int ANCHOBALA = 7;
	public final static int LARGOBALA = 15;
	
	private int velocidadY;

	/**
	 * @param pPosX
	 *            Posici�n en el eje x del objeto.
	 * @param pPosY
	 *            Posici�n en el eje y del objeto.
	 * @param pColor
	 *            Color del objeto.
	 * @param pMovX
	 *            Cambio en la posicion en el eje x del objeto.
	 * @param pMovY
	 *            Cambio en la posicion en el eje y del objeto.
	 * @param pVelocidad
	 *            Velocidad con la que viaja el disparo.
	 */
	public Disparo(int pPosX, int pPosY, Color pColor, int pMovX, int pMovY, int pVelocidadY) {
		super(pPosX, pPosY, pColor, pMovX, pMovY);

		velocidadY = pVelocidadY;
	}

	public int getVelocidad() {
		return velocidadY;
	}

	public void setVelocidad(int velocidad) {
		this.velocidadY = velocidad;
	}




	/**
	 * Retorna los limites de un objeto dado en forma de rectangulo.
	 */
	@Override
	public int[] getLimites() {
		int[] ubicacion = new int[2];
		ubicacion[0] = getPosX();
		ubicacion[1] = getPosY();
		return ubicacion;
	}

	@Override
	public void mover(int mov) {
		// TODO Auto-generated method stub
		setPosY(getPosY()+ mov);
	}
	
	///VERIFICA SI LA BALA INTERSECTO UN OBJETO 
	
	public boolean intersecto(int limites[]){
		
		int limXInf = limites[0];
		int limXSup = limites[0]+limites[2];
		
		int limYInf = limites[1];
		int limYSup = limites[1]+limites[2];
		
		if((getPosX()>=limXInf && getPosX()<= limXSup) && (getPosY()>=limYInf && getPosY()<= limYSup)){
			
			return true;
		}else{
			return false;
		}
	}

}
