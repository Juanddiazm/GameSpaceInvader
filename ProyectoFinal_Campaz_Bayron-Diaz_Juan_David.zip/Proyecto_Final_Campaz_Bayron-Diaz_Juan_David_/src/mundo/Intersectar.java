package mundo;

public interface Intersectar {
	
	boolean intersecto(int[] ubicacion);
}
