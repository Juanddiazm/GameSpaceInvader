package mundo;

import java.util.Collection;

 public class Fondo {
	 
    private int id;
    private String ruta;
    private Fondo der;
    private Fondo izq;
/**
 * @param id
 * @param ruta
 */
    public Fondo(int id, String ruta) {
	   this.id= id;
	   this.ruta = ruta;
	   der = null;
	   izq = null;
    }

    public String getRuta() {
	   return ruta;
    }

    public void setRuta(String ruta) {
	    this.ruta = ruta;
	}

    public int getId() {
	   return id;
	}

    public void setId(int id) {
	    this.id = id;
	    
     }
     
	public Fondo darIzq(){
		return izq;
	}
	
	public Fondo darDer(){
		return der;
	}
	
	public void insertarFondo(Fondo nuevo){
		
		if(nuevo.id< id){
			if(izq==null)
				izq = nuevo;
			else
				izq.insertarFondo(nuevo);
		}
		
		else {
			if(der==null)
				der = nuevo;
			else
				der.insertarFondo(nuevo);
		}
	}
	
	
	public boolean esHoja(){
		return izq == null && der == null;
	}
	
	public void inorden (Collection<Fondo> lista){
		
		if(izq!= null){
			izq.inorden(lista);
		}
	
		lista.add(this);
		
		if(der != null){
			der.inorden(lista);
		}
		
	}
	
    public Fondo buscar(int i){
    	
    	if(i==id){
    		return this;
    	}else if(i<id){
    		if(izq != null){
    			return izq.buscar(i);
    		}else{
    			return null;
    		}
    	}else{
    		if(der != null){
    			return der.buscar(i);
    		}else{
    			return null;
    		}
    	}
    	
    }




}
