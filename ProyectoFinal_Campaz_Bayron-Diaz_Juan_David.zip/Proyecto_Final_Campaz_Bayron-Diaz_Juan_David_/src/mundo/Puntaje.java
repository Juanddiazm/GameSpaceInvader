package mundo;

import java.io.Serializable;


public class Puntaje implements Serializable {

	private String nombreJugador;
	private int puntaje;

	/**
	 * @param nombreJugador
	 * @param puntaje
	 */
	public Puntaje(String nombreJugador, int puntaje) {
		
		this.nombreJugador = nombreJugador;
		this.puntaje = puntaje;
	}
	
	public String getNombreJugador() {
		return nombreJugador;
	}
	
	public void setNombreJugador(String nombreJugador) {
		this.nombreJugador = nombreJugador;
	}
	
	public int getPuntaje() {
		return puntaje;
	}
	
	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}
	
	public int compararPorNombre(Puntaje p){
		
		if(nombreJugador.compareToIgnoreCase(p.nombreJugador)>0){
			return 1;
		}else if (nombreJugador.compareToIgnoreCase(p.nombreJugador)==0){
			return 0;
		}else{
			return -1;
		}
		
	}
	

}
