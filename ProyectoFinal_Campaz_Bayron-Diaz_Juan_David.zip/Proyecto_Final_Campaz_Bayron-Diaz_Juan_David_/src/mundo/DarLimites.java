package mundo;


public interface DarLimites {
	/**
	 * Retorna los limites de un objeto dado en forma de rectangulo
	 * Returna el espacio ocupado por el objeto en forma de cuadrilatero
	 */
	public abstract int[] getLimites();
	
}
