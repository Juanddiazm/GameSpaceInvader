package mundo;

import java.awt.Color;


public class Nave extends ObjetoJuego implements Movimiento {
	// Tama�o de la nave
	public final static int TAMA�O_NAVE = 50;
	public final static int VIDA_INICIAL = 3;
	private int numVida;

	

	/**
	 * Constructor de la nave
	 * 
	 * @param posX
	 *            Posici�n en el eje x del objeto.
	 * @param posY
	 *            Posici�n en el eje y del objeto.
	 * @param color
	 *            Color del objeto.
	 */
	public Nave(int pPosX, int pPosY, Color pColor, int pNumVida) {
		super(pPosX, pPosY, pColor);
		numVida = pNumVida;
	}

	/**
	 * Retorna los limites de la nave dado en forma de rectangulo
	 */
	@Override
	public int[] getLimites() {
		int[] ubicacion = new int[3];
		ubicacion[0] = getPosX();
		ubicacion[1] = getPosY();
		ubicacion[2] = TAMA�O_NAVE;
		return ubicacion;
	}

	/**
	 * Movimiento de la nave
	 */

	@Override

	public void mover(int mov) {

		if (getPosX() > 1000) {
			setPosX(-50);
		} else if (getPosX() < -50) {
			setPosX(1000);
		} else {
			setPosX(getPosX() + mov);
		}

	}
	/**
	 * @return the numVida
	 */
	public int getNumVida() {
		return numVida;
	}

	/**
	 * @param numVida the numVida to set
	 */
	public void setNumVida(int numVida) {
		this.numVida = numVida;
	}
}
