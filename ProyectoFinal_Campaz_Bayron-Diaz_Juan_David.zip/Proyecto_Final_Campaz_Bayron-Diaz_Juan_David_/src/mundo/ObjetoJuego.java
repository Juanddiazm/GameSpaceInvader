package mundo;

import java.awt.Color;


public abstract class ObjetoJuego implements DarLimites {
	// posicion en el eje x
	private int posX;
	// posicion en el eje y
	private int posY;
	// color del objeto
	private Color color;

	/**
	 * Constructor de la clase
	 * 
	 * @param posX
	 *            Posici�n en el eje x del objeto.
	 * @param posY
	 *            Posici�n en el eje y del objeto.
	 * @param color
	 *            Color del objeto.
	 */
	public ObjetoJuego(int posX, int posY, Color color) {
		super();
		this.posX = posX;
		this.posY = posY;
		this.color = color;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	/**
	 * Retorna los limites de un objeto dado en forma de rectangulo
	 */
	public abstract int[] getLimites();

}
