package mundo;

public interface Movimiento {
	/**
	 * Movimiento de los objetos
	 */
	void mover(int mov);
}
