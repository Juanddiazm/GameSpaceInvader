package mundo;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Juego {
	
	//----------------------------//
	//Constantes
	//---------------------------//
	
	public static final int NUM_INVASORES_FILA = 7;
	public static final int NUM_FILAS = 5;
	public static final int VEL_NORMAL = 10;
	public static final int DISTANCIA_INVASORES = 70;
	public static final int ANCHO_JUEGO = 1000;
	public static final String NOMBRE_ULTIMO_JUEGO = "datos/UltimoJuegoGuardado.txt";
	public final static String RUTA_PUNTAJE = "./datos/puntaje";
	public final static String RUTA_PUNTAJE_ACTUAL = "./datos/puntajeActual";
	public final static int NUM_FONDOS =10;
	
	//---------------------------//
	//Atributos//
	//--------------------------//
	
	private Nave nave;
	private int nivel;
	private Fondo raizFondo;
	private int puntajeActual;
	private Invasor primerInvasor;
	private Disparo balaInvasor;
	private Disparo balaNave;
	private int marcadorX, marcadorY;
	private String fondoActual;
	boolean puedeDispararDeNuevo;
	private boolean impacto;
	private boolean juegoActivo;
	private ArrayList<Puntaje> puntajes;
	
	//----------------------//
	//Constructor
	//---------------------//
	
	public Juego(){
		puntajes = new ArrayList<Puntaje>();
		cargarPuntaje();
		nuevaPartida();
		inicializacionFondos();
		
	}
	
	//-------------------//
	//Metodos
	//-------------------//
	
	
	public void nuevaPartida(){
		nave = new Nave(375, 600, null, 3);
		nivel = 1;
		iniciarInvasores();
		puntajeActual=0;
		puedeDispararDeNuevo = true;
		juegoActivo = true;	
		balaNueva();
		balaNave = new Disparo(nave.getPosX()+22,nave.getPosY()-15,Color.GREEN,0,10,VEL_NORMAL);
		
	}
	
	public void iniciarInvasores(){
		int tipoInvasor = 0;
		for(int i =0;i<NUM_INVASORES_FILA; i++){
			if(tipoInvasor!=3){
				tipoInvasor++;
			}else{
				tipoInvasor=1;
			}
			for(int j=0; j<NUM_FILAS; j++){
				;
				Invasor nuevo = new Invasor(DISTANCIA_INVASORES*i, DISTANCIA_INVASORES*j, 
						Color.DARK_GRAY, VEL_NORMAL,VEL_NORMAL,tipoInvasor, 40, 40);
				agregarInvasor(nuevo);	
			}
		}
	}
	
	public boolean murieronTodosLosInvasores(){
		Invasor actual = primerInvasor;
		boolean resultado = true;
		while(actual != null && resultado){
			
			if(actual.isEstaVivo()){
				resultado =false;
			}
			actual = actual.getSiguiente();
			}
		return resultado;
		
	}


	public boolean intersectoNave(){	
		
		if(balaInvasor.intersecto(nave.getLimites())){
			nave.setNumVida(nave.getNumVida()-1);
			
			balaInvasor.setPosY(900);
			if(nave.getNumVida()==0){
				juegoActivo = false;
			}
			return true;
		}else{
			return false;
		}
	}
	
	public void intersectoInvasor() {
		Invasor actual = primerInvasor;
		Invasor resultado = null;
		while (actual != null) {

			if (balaNave.intersecto(actual.getLimites()) && actual.isEstaVivo()) {
				actual.setEstaVivo(false);
				balaNave.setPosY(-30);
				resultado = actual;
				impacto = true;
				puntajeActual += 100;
				marcadorX = resultado.getPosX();
				marcadorY = resultado.getPosY();
			}
			actual = actual.getSiguiente();
		}
		
	}
	
	public void invasoresBajaron(){
		Invasor actual= primerInvasor;
		while(actual!=null){
			if(actual.isEstaVivo()&&actual.getPosY()>530){
				nave.setNumVida(0);
				juegoActivo = false;
			}
			actual=actual.getSiguiente();
		}
	}

	public void verificarEstado(){
		
		intersectoInvasor();
		intersectoNave();
		invasoresBajaron();
		
		if(murieronTodosLosInvasores()){
			nivel ++;
			
			revivirInvasores();
		}		
	}
	
	public void revivirInvasores() {
		Invasor actual = primerInvasor;
		for (int i = 0; i < NUM_INVASORES_FILA; i++) {
			for (int j = 0; j < NUM_FILAS; j++) {
				actual.setEstaVivo(true);

				actual.setPosY(DISTANCIA_INVASORES * j);
				int nuevaVelocidad = (int) ((int) actual.getMovX() * nivel*(0.6));
				actual.setMovX(nuevaVelocidad);

				actual = actual.getSiguiente();
			}
		}
	}
	
	
	public void inicializacionFondos(){
		
		Fondo nuevo = new Fondo(5,"data/fondos/5.jpg");
		raizFondo = nuevo;
		
		for(int i = 0; i<NUM_FONDOS; i++){
			Fondo nuevo2 = new Fondo(i,"data/fondos/"+i+".jpg");
			if(i != 5){
				raizFondo.insertarFondo(nuevo2);
			}
		}
	}
	
	
	public void agregarInvasor(Invasor nuevo){
		
		nuevo.setSiguiente(primerInvasor);
		primerInvasor = nuevo;
		
	}
	
	public void balaNueva(){
		
		int posXBala = (int) (Math.random()*ANCHO_JUEGO)+10;
		balaInvasor = new Disparo(posXBala, 40, Color.YELLOW, 0 , 10, VEL_NORMAL);
	}
	

	
	public ArrayList<Invasor> darInvasores(){
		
		ArrayList<Invasor> array = new ArrayList<Invasor>();
		Invasor actual = primerInvasor;
		
		while (actual != null){
			array.add(actual);
			actual = actual.getSiguiente();
		}
		return array;
	}
	
	
	public void cargarPuntaje(){
		
		ObjectInputStream ois = null;
        try
        {
            File archivo = new File( RUTA_PUNTAJE );
            if( archivo.exists( ) )
            {
                ois = new ObjectInputStream( new FileInputStream( archivo ) );
                puntajes = ( ArrayList<Puntaje> )ois.readObject( );
                ois.close( );
            }
            

        }
        catch( IOException  | ClassNotFoundException e )
        {
           e.printStackTrace();
        }
		
	}
	
    public void guardarPuntaje() throws FileNotFoundException, IOException{
		
		 ObjectOutputStream oos = new ObjectOutputStream( new FileOutputStream( RUTA_PUNTAJE) );
         oos.writeObject( puntajes );
         oos.close( );
	}
	
	public void guardarJuego() throws IOException{
		
		Puntaje puntajeActual = new Puntaje(" ", this.puntajeActual);
		ObjectOutputStream oos = new ObjectOutputStream( new FileOutputStream( RUTA_PUNTAJE_ACTUAL) );
		oos.writeObject(puntajeActual);
		
		File file = new File(NOMBRE_ULTIMO_JUEGO);
		PrintWriter escritor = new PrintWriter(file);
		escritor.println("Nivel");
		escritor.println(nivel);
		escritor.println("INVASORES");
		Invasor actual = primerInvasor;
		
		while (actual != null){
			escritor.println(actual.getPosX()+ " "+ actual.getPosY()+" "+actual.getColor()+" "+actual.getMovX()+" "+actual.getMovY()+" "
					+actual.getTipoDeInvasor()+" "+actual.getAncho()+" "+actual.getAlto()+" "+actual.isEstaVivo());
			actual = actual.getSiguiente();
		}
		
		escritor.println("nave");
		
		escritor.println(nave.getPosX()+" " +nave.getPosY()+" "+ nave.getColor()+ " " + nave.getNumVida());
		
		escritor.close();
	
	}
	
	
	public void cargarJuego() throws IOException{
		
		ObjectInputStream ois = null;
        try
        {
            File archivo = new File( RUTA_PUNTAJE_ACTUAL );
            if( archivo.exists( ) )
            {
                ois = new ObjectInputStream( new FileInputStream( archivo ) );
                Puntaje puntaje = ( Puntaje )ois.readObject( );
                puntajeActual = puntaje.getPuntaje();
                ois.close( );
            }
            else
            {
                puntajeActual = 0;
            }
        }
        catch( IOException  | ClassNotFoundException e )
        {
           e.printStackTrace();
        }
		
		File file = new File(NOMBRE_ULTIMO_JUEGO);
		FileReader archivo = new FileReader(file);
		BufferedReader lector = new BufferedReader(archivo);
		String linea = lector.readLine();
		nivel = Integer.parseInt(lector.readLine());
		linea = lector.readLine();
		linea = lector.readLine();
		ArrayList<Invasor> invasores = new ArrayList<Invasor>();
		
		while(!linea.equals("nave")){
			
			String datos[] = linea.split(" ");
			
			int posX = Integer.parseInt(datos[0]);
			int posY = Integer.parseInt(datos[1]);
			//FALTA RELACIONAR EL COLOR
			int movX = Integer.parseInt(datos[3]);
			int movY = Integer.parseInt(datos[4]);
			int tipoInvasor = Integer.parseInt(datos[5]);
			int ancho = Integer.parseInt(datos[6]);
			int alto = Integer.parseInt(datos[7]);
			
			
			Invasor nuevo = new Invasor(posX,posY, Color.RED,movX,movY,tipoInvasor,ancho,alto);
			if(datos[8].equals("false")){
				nuevo.setEstaVivo(false);
			}
			
			invasores.add(nuevo);
			linea = lector.readLine();
			
		}
		
		primerInvasor = null;
		
		for(int i=invasores.size()-1; i>=0; i--){	
			agregarInvasor(invasores.get(i));
		}
		
		linea = lector.readLine();
		
		String datos2[] = linea.split(" ");
		
		int navePosX =Integer.parseInt(datos2[0]);
		int navePosY = Integer.parseInt(datos2[1]);
		//Falta Color
		int vidas = Integer.parseInt(datos2[3]);
		nave =  new Nave(navePosX,navePosY, Color.WHITE, vidas);
		juegoActivo = true;
		puedeDispararDeNuevo= true;
	}
	
	public void continuarJuego () throws IOException{
		cargarJuego();
	}


	

	
	//----------------------//
	//ORDENAMIENTO INSERCION//
	//---------------------//
	public void ordenarPuntajesAscendentemente(){
		
		for (int i = 1; i < puntajes.size(); i++) {
			for (int j = i; j > 0
					&& puntajes.get(j - 1).getPuntaje()>puntajes.get(j).getPuntaje() ; j--) {
				Puntaje temporal = puntajes.get(j);
				puntajes.set(j, puntajes.get(j - 1));
				puntajes.set(j - 1, temporal);
			}
		}
	}
	
	//----------------------//
	//BUSQUEDA BINARIA//
	//---------------------//
	
	public Puntaje buscarPuntaje(String nombre) {
		
		boolean encontre=false;
		int inicio=0;
		int fin=puntajes.size()-1;
		
		Puntaje resultado = null;
		while(inicio<=fin && !encontre){
			int medio= (inicio+fin)/2;
			
			if(puntajes.get(medio).getNombreJugador().compareTo(nombre)==0){
				encontre=true;
				resultado=puntajes.get(medio);
			}
			else if(puntajes.get(medio).getNombreJugador().compareTo(nombre)>0){
					fin= medio-1;
			}
			else{
				inicio=medio+1;
			}
				
			}
			return resultado;
		}
	
	

	public void agregarPuntaje(String nombre) throws NombreYaExisteException, CampoVacioException{
		
		Puntaje nuevo = new Puntaje(nombre, puntajeActual);
		
		if(nombre.equals("")){
			throw new CampoVacioException("Digite un nombre valido");
		}else{
			cargarPuntaje();
		if(buscarPuntaje(nombre)!= null){
			throw new NombreYaExisteException("El nombre ya ha sido escogido");
		}else{
			puntajes.add(nuevo);
		}
		}	
		}
	
	public ArrayList<Puntaje> darPuntajes(){
		return puntajes;
	}
		
	public ArrayList<Fondo> darFondos(){
		ArrayList lista = new ArrayList();
		raizFondo.inorden(lista);
		return lista;
		
	}
	
	public boolean isJuegoActivo() {
		return juegoActivo;
	}
	
	public void cambiarFondo(int fondo){
		fondoActual = raizFondo.buscar(fondo).getRuta();
	}
	
	public String darFondoActual(){
		return fondoActual;
	}
	
	public Fondo buscarFondo(int num){
		return raizFondo.buscar(num);
	}
	
	public int getPuntajeActual() {
		return puntajeActual;
	}


	public void setPuntajeActual(int puntajeActual) {
		this.puntajeActual = puntajeActual;
	}
	
	public Disparo getBalaInvasor() {
		return balaInvasor;
	}


	public void setBalaInvasor(Disparo balaInvasor) {
		this.balaInvasor = balaInvasor;
	}
	
	public boolean isImpacto() {
		return impacto;
	}


	public void setImpacto(boolean impacto) {
		this.impacto = impacto;
	}

	public boolean isPuedeDispararDeNuevo() {
		return puedeDispararDeNuevo;
	}


	public void setPuedeDispararDeNuevo(boolean puedeDispararDeNuevo) {
		this.puedeDispararDeNuevo = puedeDispararDeNuevo;
	}
	

	public int getMarcadorX() {
		return marcadorX;
	}


	public void setMarcadorX(int marcadorX) {
		this.marcadorX = marcadorX;
	}


	public int getMarcadorY() {
		return marcadorY;
	}


	public void setMarcadorY(int marcadorY) {
		this.marcadorY = marcadorY;
	}
	
	public Disparo getBalaNave(){
		return balaNave;
	}
	

	public void setJuegoActivo(boolean juegoActivo) {
		this.juegoActivo = juegoActivo;
	}
	
	public Invasor darPrimerInvasor(){
		return primerInvasor;
	}
	
	public Nave getNave() {
		return nave;
	}


	public void setNave(Nave nave) {
		this.nave = nave;
	}
	
	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public ArrayList<Puntaje> getPuntajes() {
		return puntajes;
	}

	public void setPuntajes(ArrayList<Puntaje> puntajes) {
		this.puntajes = puntajes;
	}

	public Fondo getRaizFondo() {
		return raizFondo;
	}

	public void setRaizFondo(Fondo raizFondo) {
		this.raizFondo = raizFondo;
	}
	
	


}
