package test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import junit.framework.TestCase;
import mundo.CampoVacioException;
import mundo.Invasor;
import mundo.Juego;
import mundo.Nave;
import mundo.NombreYaExisteException;

public class JuegoTest extends TestCase {
	private Juego juego;

	// Escenario con el juego iniciado
	private void setupEscenario1() {
		juego = new Juego();
	}

	// Escenario con invasores iniciados
	private void setupEscenario2() {
		juego = new Juego();
		juego.iniciarInvasores();
		// Definicion de la posicion de la bala del invasor y la
		// nave(interceptando)
		juego.getBalaInvasor().setPosX(0);
		juego.getBalaInvasor().setPosY(0);
		juego.getNave().setPosX(0);
		juego.getNave().setPosY(0);
		// Definicion de la posicion del primer invasor y la bala de la
		// nave(interceptando)
		juego.darPrimerInvasor().setPosX(10);
		juego.darPrimerInvasor().setPosY(10);
		juego.getBalaNave().setPosX(10);
		juego.getBalaNave().setPosY(10);
	}

	private void setupEscenario3() {
		juego = new Juego();
		juego.iniciarInvasores();

	}

	// Escenario con tres puntajes
	private void setupEscenario4() {
		juego = new Juego();
		juego.iniciarInvasores();
		juego.setPuntajeActual(5000);
		try {
			juego.agregarPuntaje("Juan");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
		juego.setPuntajeActual(2000);
		try {
			juego.agregarPuntaje("Felix");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
		juego.setPuntajeActual(100);
		try {
			juego.agregarPuntaje("TuGfa");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
		juego.setPuntajeActual(8000);
		try {
			juego.agregarPuntaje("Jairo");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
		juego.setPuntajeActual(50);
		try {
			juego.agregarPuntaje("Ramon");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
		juego.setPuntajeActual(1400000);
		try {
			juego.agregarPuntaje("Esteban");
		} catch (NombreYaExisteException e) {
		} catch (CampoVacioException e) {
		}
	}

	public void testNuevaPartida() {
		setupEscenario1();
		juego.nuevaPartida();

		// Verifica que los atributos se inicialicen correctamente
		assertNotNull("La nave es null", juego.getNave());
		assertEquals("El nivel no es igual al valor de inicializacion", 1, juego.getNivel());
		assertEquals("El puntaje actual no es igual al valor de inicializacion", 0, juego.getPuntajeActual());
		assertTrue("El atributo deberia ser verdadero", juego.isPuedeDispararDeNuevo());
		assertTrue("El atributo deberia ser verdadero", juego.isJuegoActivo());
		assertNotNull("La bala de la nave es null", juego.getBalaNave());
	}

	public void testIniciarInvasores() {
		setupEscenario1();
		// Verifica que los invasores se inicializacion de forma correcta
		Invasor actual = juego.darPrimerInvasor();
		for (int i = 0; i < juego.NUM_INVASORES_FILA; i++) {
			for (int j = 0; j < juego.NUM_FILAS; j++) {
				assertNotNull("La nave es null", actual);
				actual = actual.getSiguiente();
			}
		}
	}

	public void testMurieronTodosLosInvasores() {
		setupEscenario2();
		// Verifica que todos los invasores se encuentran vivos
		assertFalse("Los invasores inicializaron como muertos", juego.murieronTodosLosInvasores());
	}

	public void testIntersectoNave() {
		setupEscenario2();
		// verifica que la nave y la bala del invasor intercepto
		assertTrue("No se registra la intercepci�n", juego.intersectoNave());

		juego.getNave().setPosX(50);
		juego.getNave().setPosY(50);
		// verifica que la nave y la bala del invasor no intercepto
		assertFalse("Registra una intercepci�n", juego.intersectoNave());
	}

	public void testIntersectoInvasor() {
		setupEscenario2();

		juego.intersectoInvasor();
		assertFalse("No se registra la intercepci�n", juego.darPrimerInvasor().isEstaVivo());

		juego.darPrimerInvasor().setPosX(50);
		juego.darPrimerInvasor().setPosY(50);
		juego.darPrimerInvasor().setEstaVivo(true);

		juego.intersectoInvasor();
		assertTrue("Registro una intercepci�n", juego.darPrimerInvasor().isEstaVivo());
	}

	public void testIinvasoresBajaron() {
		setupEscenario3();
		juego.invasoresBajaron();
		assertEquals("El numero de vidas es diferente de 3", 3, juego.getNave().getNumVida());
		assertTrue("El juego esta desactivado", juego.isJuegoActivo());

		juego.darPrimerInvasor().setPosY(600);
		juego.invasoresBajaron();
		assertEquals("El numero de vidas es diferente de 0", 0, juego.getNave().getNumVida());
		assertFalse("El juego esta activado", juego.isJuegoActivo());
	}

	public void testRevivirinvasores() {
		setupEscenario3();
		juego.darPrimerInvasor().setEstaVivo(false);

		juego.revivirInvasores();
		assertTrue(juego.darPrimerInvasor().isEstaVivo());
	}

	public void testInicializarFondos() {
		setupEscenario3();
		juego.inicializacionFondos();

		assertNotNull("El primer fondo es null", juego.getRaizFondo());
	}

	public void testAgregarInvasor() {
		setupEscenario1();
		Invasor invasor = new Invasor(0, 0, null, 0, 0, 0, 0, 0);
		juego.agregarInvasor(invasor);

		assertEquals("No agrego de forma correcta", invasor, juego.darPrimerInvasor());

	}

	public void testBalaNueva() {
		setupEscenario3();
		juego.balaNueva();
		assertNotNull("La bala no se creo", juego.getBalaInvasor());
	}

	public void testDarInvasores() {
		setupEscenario3();
		ArrayList<Invasor> array = juego.darInvasores();
		assertEquals(juego.darPrimerInvasor(), array.get(0));
	}

	public void testAgregarPuntaje() {
		setupEscenario3();
		juego.setPuntajeActual(5000);
		try {
			juego.agregarPuntaje("Juan");
		} catch (NombreYaExisteException e) {
			fail("El nombre esta repetido(?)");
		} catch (CampoVacioException e) {
			fail("El nombre ingresado es un campo vacio(?)");
		}
		assertEquals("Los nombres no son iguales", "Pedro", juego.getPuntajes().get(0).getNombreJugador());
	}

	public void testBuscarPuntaje() {
		setupEscenario4();
		assertNull("No se realiza bien la busqueda", juego.buscarPuntaje("Juan"));
	}

	public void testOrdenarPuntajesAscendentemente() {
		setupEscenario4();
		juego.ordenarPuntajesAscendentemente();
		assertEquals("Este deberia ser el menor", juego.getPuntajes().get(0).getPuntaje(), 2500);
		assertEquals("No se realiza bien el ordenamiento", juego.getPuntajes().get(1).getPuntaje(), 5300);
		assertEquals("No se realiza bien el ordenamiento", juego.getPuntajes().get(2).getPuntaje(), 9300);
		assertEquals("No se realiza bien el ordenamiento", juego.getPuntajes().get(3).getPuntaje(), 1400000);
		assertEquals("No se realiza bien el ordenamiento", juego.getPuntajes().get(4).getPuntaje(), 1400000);
		assertEquals("No se realiza bien el ordenamiento", juego.getPuntajes().get(5).getPuntaje(), 1400000);

	}


	public void testPuntajes() {
		setupEscenario4();
		try {
			juego.guardarPuntaje();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}
		juego.setPuntajes(null);

		juego.cargarPuntaje();
		assertNotNull("El arrego de puntajes no se cargo correctamente", juego.getPuntajes());
	}

	public void testGuardarCargarJuego() {
		setupEscenario4();

		juego.setNivel(6);
		try {
			juego.guardarJuego();
		} catch (IOException e) {
		}

		juego.setNivel(0);
		

		try {
			juego.cargarJuego();
		} catch (IOException e) {

		}

		assertEquals("El nivel no se cargo o guardo de forma correcta", 6, juego.getNivel());


	}

}
