package test;

import java.awt.Color;

import junit.framework.TestCase;
import mundo.Disparo;

public class DisparoTest extends TestCase{

	private Disparo disparo1;
	
	
	private void setupEscenario1(){
		
		disparo1 = new Disparo(200,40,Color.RED,20,20,15);	
	}
	
	public void testDarLimites(){
		setupEscenario1();
		
		assertEquals(200, disparo1.getLimites()[0]);
		
		assertEquals(40,disparo1.getLimites()[1]);
		
	}
	
	public void testIntersecto(){
		setupEscenario1();
		
		int limites[] = {200,38,30};
		assertTrue(disparo1.intersecto(limites));
		
		int limites2[] = {20,68,40};
		assertFalse(disparo1.intersecto(limites2));
	}
	
	public void testMover(){
		setupEscenario1();
		
		disparo1.mover(20);
		assertEquals(60, disparo1.getPosY());
		
		disparo1.mover(-10);
		assertEquals(50,disparo1.getPosY());
	}
	
	public void testVelocidad(){
		setupEscenario1();
		
		assertEquals(15,disparo1.getVelocidad());
		disparo1.setVelocidad(25);
		assertEquals(25,disparo1.getVelocidad());
	}
}
