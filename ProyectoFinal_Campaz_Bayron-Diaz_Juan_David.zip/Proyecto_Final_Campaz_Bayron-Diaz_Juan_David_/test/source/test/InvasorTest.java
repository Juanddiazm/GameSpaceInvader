package test;

import java.awt.Color;

import junit.framework.TestCase;
import mundo.Invasor;

public class InvasorTest extends TestCase{

	private Invasor invasor1;
	private Invasor invasor2;
	
	private void setupEscenario1(){
		
		invasor1 = new Invasor(145,95, Color.RED,20,20,15,21,20);
		
		invasor2 = new Invasor(250,500,Color.YELLOW,10,10,15,13,14);
		
	}
	
	public void testDarLimites(){
		setupEscenario1();
		
		assertEquals(145, invasor1.getLimites()[0]);
		
		assertEquals(95,invasor1.getLimites()[1]);
		
	}
	
	public void testMover(){
		setupEscenario1();
		
		invasor1.mover(20);
		assertEquals(165, invasor1.getPosX());
		
		invasor2.mover(25);
		assertEquals(250,invasor2.getPosX());
	}
	
	public void testDarInvasor(){
		setupEscenario1();
		
		assertEquals(15,invasor1.getTipoDeInvasor());
		invasor1.setTipoDeInvasor(2);;
		assertEquals(2,invasor1.getTipoDeInvasor());
	}
	
	public void testEstadoInvasor(){
		setupEscenario1();
		
		assertEquals(true,invasor1.isEstaVivo());
		invasor1.setEstaVivo(false);;
		assertEquals(false,invasor1.isEstaVivo());
	}
	
	public void testAnchoInvasor(){
		setupEscenario1();
		
		assertEquals(21,invasor1.getAncho());
		invasor1.setAncho(25);;
		assertEquals(25,invasor1.getAncho());
	}
	
	
	public void testAltoInvasor(){
		setupEscenario1();
		
		assertEquals(13,invasor2.getAncho());
		invasor2.setAncho(26);;
		assertEquals(26,invasor2.getAncho());
	}
	
	public void testSiguienteInvasor(){
		setupEscenario1();
		
		assertNull((invasor1.getSiguiente()));
		invasor1.setSiguiente(invasor2);
		assertNotNull(invasor1.getSiguiente());
	}
}
