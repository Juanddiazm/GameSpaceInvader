package test;

import java.util.ArrayList;
import java.util.Collection;

import junit.framework.TestCase;
import mundo.Fondo;

public class FondoTest extends TestCase{

	private Fondo fondo;
	
	private int id;
	private String ruta;
	
	private void setupEscenario1(){
		id= 4;
		ruta = "ruta1/";
		
		fondo = new Fondo(id,ruta);
	}
	
	private void setupEscenario2(){
		
		setupEscenario1();
		
		int id= 3;
		String ruta = "ruta2/";
		
		Fondo fondo2 = new Fondo(id,ruta);
		fondo.insertarFondo(fondo2);
	}
	
	private void setupEscenario3(){
		
		setupEscenario2();
		
		int id= 6;
		String ruta = "ruta3/";
		
		Fondo fondo2 = new Fondo(id,ruta);
		fondo.insertarFondo(fondo2);
	}
	
	private void setupEscenario4(){
		
		setupEscenario3();
		
		int id= 6;
		String ruta = "ruta4/";
		
		Fondo fondo2 = new Fondo(id,ruta);
		fondo.insertarFondo(fondo2);
	}
	
	public void testInsertarIzquierda(){
		
		setupEscenario2();
		
		assertNotNull(fondo.darIzq());
		assertNull(fondo.darDer());
		
	}
	
	public void testInsertarDerecho(){
		
		setupEscenario3();
		
		assertNotNull(fondo.darIzq());
		assertNotNull(fondo.darDer());
		
		assertNull(fondo.darDer().darDer());
		assertNull(fondo.darDer().darIzq());
		assertNull(fondo.darIzq().darIzq());
		assertNull(fondo.darIzq().darDer());
	}
	
	public void testEsHoja(){
		setupEscenario1();
		assertTrue(fondo.esHoja());
		
		setupEscenario2();
		assertFalse(fondo.esHoja());
	}
	
	public void testBuscarFondo(){
		
		setupEscenario4();
		
		Fondo f;
		
		f = fondo.buscar(25);
		assertNull(f);
		
		f=fondo.buscar(6);
		assertNotNull(f);
		
		f=fondo.buscar(3);
		assertNotNull(f);
		
	}
	
	public void testInorden(){
		
        setupEscenario3( );
        Collection lista = new ArrayList( );
        fondo.inorden( lista );
        assertEquals( 3, lista.size() );
	}
	
	public void testID(){
		
		setupEscenario1();
		
		assertEquals(id, fondo.getId());
		fondo.setId(25);
		assertEquals(25, fondo.getId());
	}
	
	public void testRuta(){
		
		setupEscenario1();
		
		assertEquals(ruta, fondo.getRuta());
		fondo.setRuta("ruta/23");
		assertEquals("ruta/23", fondo.getRuta());
	}
	
	public void testDarIzquierda(){
		setupEscenario1();
		
		assertEquals(null, fondo.darIzq());
		
	}
	
	public void testDarDerecha(){
		
		setupEscenario1();
		
		assertEquals(null, fondo.darDer());
		
	}
}

