package test;

import junit.framework.TestCase;
import mundo.Puntaje;

public class PuntajeTest extends TestCase{

	Puntaje puntaje1;
	
	Puntaje puntaje2;
	
	private void setupEscenario1(){
		puntaje1 = new Puntaje("Jhon",100);
		puntaje2 = new Puntaje("Perez",5000);

	}

	public void testNombreJugador(){
		setupEscenario1();
		
		assertEquals("Jhon",puntaje1.getNombreJugador());
		puntaje1.setNombreJugador("Cristiano");
		assertEquals("Cristiano", puntaje1.getNombreJugador());
	}
	
	
	public void testPuntajeJugador(){
		setupEscenario1();
		
		assertEquals(5000,puntaje2.getPuntaje());
		puntaje2.setPuntaje(5100);;
		assertEquals(5100, puntaje2.getPuntaje());
	}
	
	public void testCompararPuntaje(){
		setupEscenario1();
		
		assertTrue(puntaje2.compararPorNombre(puntaje1)>0);
	}
}