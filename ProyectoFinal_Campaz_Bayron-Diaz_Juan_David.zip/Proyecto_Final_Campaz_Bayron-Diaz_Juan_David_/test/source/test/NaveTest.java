package test;

import java.awt.Color;

import junit.framework.TestCase;
import mundo.Nave;

public class NaveTest extends TestCase{

	private Nave nave1;
	
	private void setupEscenario1(){
		nave1 = new Nave(100,40,Color.RED, 3);
		
	}
	
	public void testDarLimites(){
		setupEscenario1();
		
		assertEquals(100, nave1.getLimites()[0]);
		
		assertEquals(40,nave1.getLimites()[1]);
		
	}
	
	public void testNumVida(){
		setupEscenario1();
		
		assertEquals(3,nave1.getNumVida());
		nave1.setNumVida(2);
		assertEquals(2,nave1.getNumVida());
	}
	
	public void testMover(){
		setupEscenario1();
		
		nave1.mover(20);
		assertEquals(120, nave1.getPosX());
		
		nave1.mover(-100);
		assertEquals(20,nave1.getPosX());
	}
	
}
